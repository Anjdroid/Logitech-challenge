﻿                                                                                                                                                                                                                                 using UnityEngine;
using System.Collections;

public class warmUpGame : MonoBehaviour {

    string[] keyboardWords = {
    "escape",
    "f1",
    "f2",
    "f3",
    "f4",
    "f5",
    "f6",
    "f7",
    "f8",
    "f9",
    "f10",
    "f11",
    "f12",
    "sysreq",
    "scroll lock",
    "break",
    "`",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "0",
    "-",
    "equals",
    "backspace",
    "insert",
    "home",
    "page up",
    "num lock",
    "[/]",
    "[*]",
    "[-]",
    "tab",
    "q",
    "w",
    "e",
    "r",
    "t",
    "\"",
    "u",
    "i",
    "o",
    "p",
    "(",
    ")",
    "\\",
    "delete",
    "end",
    "page down",
    "[7]",
    "[8]",
    "[9]",
    "[+]",
    "caps lock",
    "a",
    "s",
    "d",
    "f",
    "g",
    "h",
    "j",
    "k",
    "l",
    ";",
    "",
    "enter",
    "[4]",
    "[5]",
    "[6]",
    "left shift",
    "z",
    "x",
    "c",
    "v",
    "b",
    "n",
    "m",
    ",",
    ".",
    "/",
    "right shift",
    "up",
    "[1]",
    "[2]",
    "[3]",
    "[enter]",
    "left ctrl",
    "left windows",
    "left alt",
    "space",
    "right alt",
    "right windows",
    "menu",
    "right control",
    "left arrow",
    "down arrow",
    "right arrow",
    "[0]",
    "[.]"
};


    int[] keyboardNums = {
    0x01,
    0x3b,
    0x3c,
    0x3d,
    0x3e,
    0x3f,
    0x40,
    0x41,
    0x42,
    0x43,
    0x44,
    0x57,
    0x58,
    0x137,
    0x46,
    0x45,
    0x29,
    0x02,
    0x03,
    0x04,
    0x05,
    0x06,
    0x07,
    0x08,
    0x09,
    0x0A,
    0x0B,
    0x0C,
    0x0D,
    0x0E,
    0x152,
    0x147,
    0x149,
    0x145,
    0x135,
    0x37,
    0x4A,
    0x0F,
    0x10,
    0x11,
    0x12,
    0x13,
    0x14,
    0x15,
    0x16,
    0x17,
    0x18,
    0x19,
    0x1A,
    0x1B,
    0x2B,
    0x153,
    0x14F,
    0x151,
    0x47,
    0x48,
    0x49,
    0x4E,
    0x3A,
    0x1E,
    0x1F,
    0x20,
    0x21,
    0x22,
    0x23,
    0x24,
    0x25,
    0x26,
    0x27,
    0x28,
    0x1C,
    0x4B,
    0x4C,
    0x4D,
    0x2A,
    0x2C,
    0x2D,
    0x2E,
    0x2F,
    0x30,
    0x31,
    0x32,
    0x33,
    0x34,
    0x35,
    0x36,
    0x148,
    0x4F,
    0x50,
    0x51,
    0x11C,
    0x1D,
    0x15B,
    0x38,
    0x39,
    0x138,
    0x15C,
    0x15D,
    0x11D,
    0x14B,
    0x150,
    0x14D,
    0x52,
    0x53,

};

    public GameObject text;
    public GameObject instructions;

    string findKey(int key) {
        string r = null;
        for (int i = 0; i < keyboardNums.Length; i++) {
            if (keyboardNums[i] == key) {
                r = keyboardWords[i];
            }
        }
        return r;
    }
    
    void sortArray()
    {

        for (int i = 0; i < keyboardNums.Length-1; i++)
        {
            if (keyboardNums[i + 1] < keyboardNums[i])
            {
                int temp = keyboardNums[i + 1];
                keyboardNums[i + 1] = keyboardNums[i];
                keyboardNums[i] = temp;
                string tmp = keyboardWords[i + 1];
                keyboardWords[i + 1] = keyboardWords[i];
                keyboardWords[i] = tmp;
            }
        }

    }

    int red,blue,green;
	double timer = 4;
	int score = 0;
	int scorePlus = 1;
	int lose = 0;
	int modraTipka = 0;
    string imeTipke = null;
	System.Random random = new System.Random();
	int nasTipka;
	int lala = 0;
	float timestamp;
    float temp;
    public bool IsEnabled = true;
 

        void Start () {
        sortArray();
        print("timpestamp " + timestamp);
		timestamp = Time.time;
		blue = 0;
		red = 0;
		green = 0;
		LogitechGSDK.LogiLedInit();
		LogitechGSDK.LogiLedSetLighting (red, green, blue);
        print("ugasnjena tipkovnica");
		for (int i = 0; i <= 10; i++) {
			blue = random.Next(20,50);
			red = random.Next(0,100);
			green = random.Next(0,100);
			nasTipka = random.Next (0, 0x53);
			LogitechGSDK.LogiLedSetLightingForKeyWithScanCode (nasTipka, red, green, blue);
            print("random obarvanje");
			if(i == 10) {
				modraTipka = nasTipka;
                imeTipke = findKey(modraTipka);
                print("modra tipka " + imeTipke);
                //imeTipke = imeTipke.ToLower();
                //print(imeTipke);
				LogitechGSDK.LogiLedSetLightingForKeyWithScanCode (modraTipka, 0, 0, 100);
			}			
		}

	}

    void Update () {
		if (lose < 3) {
            //print("lose < 3");
			temp = Time.time;
			if(Input.GetKey(imeTipke)) {
                print("najdena tipka");
				//print ("KeycodeM: " + KeyCode.M);
				lala = 1;
			}
            //print("CAJTI: " + temp + " - " + timestamp + " >? " + timer1);
			if (temp - timestamp > timer) {
				if(lala == 1) {
                    //print("score " + score);
					score += scorePlus;
                    scorePlus++;
                    //if (timer > 1)
                    //{
                        //timer = timer - 0.5;
                        //print("timer " + timer);
                    //}
					blue = 0;
					red = 0;
					green = 100;
					//LogitechGSDK.LogiLedInit();		
					LogitechGSDK.LogiLedFlashLighting (0, 100, 0, 2000, 2000);
                    print("zelen flash");
				} else {
					lose++;
					blue = 0;
					red = 100;
					green = 0;
                    //LogitechGSDK.LogiLedInit();
                    LogitechGSDK.LogiLedFlashLighting(100, 0, 0, 2000, 2000);
                    print("rdec flash");

                }
                lala = 0;
                timestamp = Time.time;
                blue = 0;
                red = 0;
                green = 0;
                print("vse se ponastavi");
                //LogitechGSDK.LogiLedInit();
                LogitechGSDK.LogiLedSetLighting(red, green, blue);
                for (int i = 0; i <= 10; i++)
                {
                    print("in ponovimo");
                    blue = random.Next(20, 50);
                    red = random.Next(0, 100);
                    green = random.Next(0, 100);
                    nasTipka = random.Next(0, 0x53);
                    LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(nasTipka, red, green, blue);
                    if (i == 10)
                    {
                        print("ponovimo drugic");
                        modraTipka = nasTipka;
                        imeTipke = findKey(modraTipka);
                        //print(modraTipka+" modra tipka");
                        LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(modraTipka, 0, 0, 100);
                    }
                }
			}
		}
        else {
            // why so blue
            //gameObject.SetActive(true);
            //print("Konec");
            blue = 0;
            red = 0;
            green = 0;
            
            //LogitechGSDK.LogiLedInit();		
            LogitechGSDK.LogiLedSetLighting (red, blue, green);
            //Application.Quit();
            IsEnabled = false;
        }
        
            if (!IsEnabled) return;

        }
}
