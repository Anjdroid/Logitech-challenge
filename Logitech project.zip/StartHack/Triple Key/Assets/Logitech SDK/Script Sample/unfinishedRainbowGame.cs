using UnityEngine;
using System.Collections;

public class unfinishedRainbowGame : MonoBehaviour
{

    // prelep pozdrav v naši kodi
    string[] keyboardWords = {
        "escape",
        "f1",
        "f2",
        "f3",
        "f4",
        "f5",
        "f6",
        "f7",
        "f8",
        "f9",
        "f10",
        "f11",
        "f12",
        "sysreq",
        "scroll lock",
        "break",
        "`",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "0",
        "-",
        "equals",
        "backspace",
        "insert",
        "home",
        "page up",
        "num lock",
        "[/]",
        "[*]",
        "[-]",
        "tab",
        "q",
        "w",
        "e",
        "r",
        "t",
        "\"",
        "u",
        "i",
        "o",
        "p",
        "(",
        ")",
        "\\",
        "delete",
        "end",
        "page down",
        "[7]",
        "[8]",
        "[9]",
        "[+]",
        "caps lock",
        "a",
        "s",
        "d",
        "f",
        "g",
        "h",
        "j",
        "k",
        "l",
        ";",
        "",
        "enter",
        "[4]",
        "[5]",
        "[6]",
        "left shift",
        "z",
        "x",
        "c",
        "v",
        "b",
        "n",
        "m",
        ",",
        ".",
        "/",
        "right shift",
        "up",
        "[1]",
        "[2]",
        "[3]",
        "[enter]",
        "left ctrl",
        "left windows",
        "left alt",
        "space",
        "right alt",
        "right windows",
        "menu",
        "right control",
        "left arrow",
        "down arrow",
        "right arrow",
        "[0]",
        "[.]"
    };
    
    int[] keyboardNums = {
        0x01,
        0x3b,
        0x3c,
        0x3d,
        0x3e,
        0x3f,
        0x40,
        0x41,
        0x42,
        0x43,
        0x44,
        0x57,
        0x58,
        0x137,
        0x46,
        0x45,
        0x29,
        0x02,
        0x03,
        0x04,
        0x05,
        0x06,
        0x07,
        0x08,
        0x09,
        0x0A,
        0x0B,
        0x0C,
        0x0D,
        0x0E,
        0x152,
        0x147,
        0x149,
        0x145,
        0x135,
        0x37,
        0x4A,
        0x0F,
        0x10,
        0x11,
        0x12,
        0x13,
        0x14,
        0x15,
        0x16,
        0x17,
        0x18,
        0x19,
        0x1A,
        0x1B,
        0x2B,
        0x153,
        0x14F,
        0x151,
        0x47,
        0x48,
        0x49,
        0x4E,
        0x3A,
        0x1E,
        0x1F,
        0x20,
        0x21,
        0x22,
        0x23,
        0x24,
        0x25,
        0x26,
        0x27,
        0x28,
        0x1C,
        0x4B,
        0x4C,
        0x4D,
        0x2A,
        0x2C,
        0x2D,
        0x2E,
        0x2F,
        0x30,
        0x31,
        0x32,
        0x33,
        0x34,
        0x35,
        0x36,
        0x148,
        0x4F,
        0x50,
        0x51,
        0x11C,
        0x1D,
        0x15B,
        0x38,
        0x39,
        0x138,
        0x15C,
        0x15D,
        0x11D,
        0x14B,
        0x150,
        0x14D,
        0x52,
        0x53,
    };

    // za devetimi gorami    
    string findKey(int key)
    {
        string r = null;
        for (int i = 0; i < keyboardNums.Length; i++)
        {
            if (keyboardNums[i] == key)
            {
                r = keyboardWords[i];
            }
        }
        return r;
    }

    //ZAkaj se joces
    void sortArray()
    {
        for (int i = 0; i < keyboardNums.Length - 1; i++)
        {
            if (keyboardNums[i + 1] < keyboardNums[i])
            {
                int temp = keyboardNums[i + 1];
                keyboardNums[i + 1] = keyboardNums[i];
                keyboardNums[i] = temp;
                string tmp = keyboardWords[i + 1];
                keyboardWords[i + 1] = keyboardWords[i];
                keyboardWords[i] = tmp;
            }
        }
    }
    
    int red, blue, green;

    int[] mavricaR = { 100, 100, 100, 100, 80, 51, 21, 0, 0, 0, 0, 0, 0, 0, 17, 47, 77, 100, 100, 100 };
    int[] mavricaG = { 0, 0, 0, 0, 0, 0, 0, 8, 38, 68, 98, 100, 100, 100, 100, 100, 100, 93, 63, 34 };
    int[] mavricaB = { 0, 30, 60, 90, 100, 100, 100, 100, 100, 100, 100, 72, 42, 13, 0, 0, 0, 0, 0, 0 };

    int score = 0;
    int scorePlus = 10;
    int lose = 0;
    static int stopnja = 1; 
    System.Random random = new System.Random();
    int nasTipka;
    int tipka;
    int zac = 0;
    static int zap = 20;//(int)(20 / stopnja);    
    int zap1 = 20;
    int[] Zaporedja;
    int indeks = 0;
    string keyInput;
    int prvic = 0;
    bool isEnabled = true;

    void Start()
    {
        sortArray();
        Zaporedja = new int[20];        
        LogitechGSDK.LogiLedInit();
        LogitechGSDK.LogiLedSetLighting(0, 0, 0);
        for (int i = 0; i < 20; i++)
        {
            //print("1");
            blue = mavricaB[i];
            red = mavricaR[i];
            green = mavricaG[i];
            nasTipka = random.Next(0, 0x53);
            Zaporedja[i] = nasTipka;
            LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(nasTipka, red, green, blue);   
        }
        prvic = 0;
        //keyInput = Input.inputString;
        // kaj sedaj                  
    }


    /*void dolociVrednostZac()
    {
        for (int j = 0; j < 20; j++)
        {
            if (keyInput.Equals(findKey(Zaporedja[j])))
            {
                zac = j;
            }
        }
    }*/


    void generirajZap() {
        //indeks = 0;
        //LogitechGSDK.LogiLedInit();
        LogitechGSDK.LogiLedSetLighting(0, 0, 0);
        for (int i = 0; i < 20; i++)
        {
            blue = mavricaB[i];
            red = mavricaR[i];
            green = mavricaG[i];
            nasTipka = random.Next(0, 0x53);
            Zaporedja[i] = nasTipka;
            //indeks++;
            LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(nasTipka, red, green, blue);
        }
        zac = 0;
        zap1 = 20;
        prvic = 0;
    }

    // tuki dogaja    
    void Update()
    {
        //int bla = 0;
        
        //print("updejtam");
        keyInput = Input.inputString;
        
        /*if (prvic == 0)
        {
            prvic = 1;
            for (int j = 0; j < 20; j++)
            {
                //print(keyInput);
                //print(findKey(Zaporedja[j]));                
                if (keyInput.Equals(findKey(Zaporedja[j])))
                {
                    print("dolocam zac");
                    //print("5b468764945");
                    zac = j;
                    bla = 1;
                    LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(Zaporedja[j], 0, 0, 0);
                    zap1--;
                }
            }
            if (bla == 0)
            {
               //la = 1;
                //prvic = 0;
                lose++;
                //print("losam "+ lose);
                round = 0;
                generirajZap();
                dolociVrednostZac();
            }            
        }
        else {*/
            print("updejt");
            if (lose < 3)
            {
                print("3");
                if (zap1 > 0)
                {
                    print(zac);
                    if (prvic == 0) {
                        print("prvic");
                        prvic = 1;
                        if (keyInput.Equals(findKey(Zaporedja[0]))) {
                            zap1--;
                            LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(Zaporedja[0], 0, 0, 0);
                        }
                        else if (!keyInput.Equals("")) {
                        print("looser1");
                            lose++;
                            //LogitechGSDK.LogiLedFlashLighting(100, 0, 0, 2000, 2000);
                            LogitechGSDK.LogiLedSetLighting(0, 0, 0);
                            generirajZap();
                        }
                    }
                    else if (zac == 0 && (keyInput.Equals(findKey(Zaporedja[1])) || keyInput.Equals(findKey(Zaporedja[19]))))
                    {
                        print("prvi zac");
                        if (keyInput.Equals(findKey(Zaporedja[1])))
                        {
                            zac = 1;
                        }
                        else {
                            zac = 19;
                        }
                        LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(Zaporedja[zac], 0, 0,0);
                        print("brisem 1");
                        zap1--;
                    }
                    else if (zac == 19 && (keyInput.Equals(findKey(Zaporedja[0])) || keyInput.Equals(findKey(Zaporedja[zac - 1]))))
                    {
                        print("drugi zac");
                        if (keyInput.Equals(findKey(Zaporedja[0])))
                        {
                            zac = 0;
                        }
                        else {
                            zac = zac - 1;
                        }
                        LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(Zaporedja[zac], 0, 0, 0);
                        print("brisem 2");
                        zap1--;
                    }
                    else if (((zac < 19) && keyInput.Equals(findKey(Zaporedja[zac + 1]))) || (zac > 0) && (keyInput.Equals(findKey(Zaporedja[zac - 1]))))
                    {
                        print("tretji zac");
                        if (keyInput.Equals(findKey(Zaporedja[zac + 1])))
                        {
                            zac = zac + 1;
                        }
                        else {
                            zac = zac - 1;
                        }
                        LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(Zaporedja[zac], 0, 0, 0);
                        print("brisem 3");
                        zap1--;
                    }
                   
                    else if (!keyInput.Equals("")) {
                        print("looser2");
                        lose++;
                        //LogitechGSDK.LogiLedFlashLighting(100, 0, 0, 2000, 2000);
                        LogitechGSDK.LogiLedSetLighting(0, 0, 0);
                        generirajZap();
                        //dolociVrednostZac();
                    
                    print("4");
                    //print(zac);
                    }
                    
                }

                else { //zmaga runde	
                    print("victory");	
                    LogitechGSDK.LogiLedFlashLighting(0, 100, 0, 2000, 2000);
                    LogitechGSDK.LogiLedSetLighting(0, 0, 0);
                    score += scorePlus;
                    scorePlus++;
                    zac = 0;
                    zap1 = zap;
                    generirajZap();
                isEnabled = false;
                    //dolociVrednostZac();
                }
            }
            else {
                print("ne 3");
                //LogitechGSDK.LogiLedFlashLighting(100, 0, 0, 2000, 2000);
                LogitechGSDK.LogiLedSetLighting(100, 0, 0);

                // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
                for (int j = 0; j < 10000000; j++)
                {
                    int barva = random.Next(0, 11);
                }
            isEnabled = false;

                LogitechGSDK.LogiLedSetLighting(0, 0, 0);
                LogitechGSDK.LogiLedShutdown();
            }
        if (!isEnabled) return;
        //}
    }
}
