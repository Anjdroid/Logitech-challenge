﻿using UnityEngine;
using System.Collections;

public class memoryGame : MonoBehaviour {

    string[] keyboardWords = {
        "escape",
        "f1",
        "f2",
        "f3",
        "f4",
        "f5",
        "f6",
        "f7",
        "f8",
        "f9",
        "f10",
        "f11",
        "f12",
        "sysreq",
        "scroll lock",
        "break",
        "`",
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "0",
        "-",
        "equals",
        "backspace",
        "insert",
        "home",
        "page up",
        "num lock",
        "[/]",
        "[*]",
        "[-]",
        "tab",
        "q",
        "w",
        "e",
        "r",
        "t",
        "\"",
        "u",
        "i",
        "o",
        "p",
        "(",
        ")",
        "\\",
        "delete",
        "end",
        "page down",
        "[7]",
        "[8]",
        "[9]",
        "[+]",
        "caps lock",
        "a",
        "s",
        "d",
        "f",
        "g",
        "h",
        "j",
        "k",
        "l",
        ";",
        "",
        "enter",
        "[4]",
        "[5]",
        "[6]",
        "left shift",
        "z",
        "x",
        "c",
        "v",
        "b",
        "n",
        "m",
        ",",
        ".",
        "/",
        "right shift",
        "up",
        "[1]",
        "[2]",
        "[3]",
        "[enter]",
        "left ctrl",
        "left windows",
        "left alt",
        "space",
        "right alt",
        "right windows",
        "menu",
        "right control",
        "left arrow",
        "down arrow",
        "right arrow",
        "[0]",
        "[.]"
    };


    int[] keyboardNums = {
        0x01,
        0x3b,
        0x3c,
        0x3d,
        0x3e,
        0x3f,
        0x40,
        0x41,
        0x42,
        0x43,
        0x44,
        0x57,
        0x58,
        0x137,
        0x46,
        0x45,
        0x29,
        0x02,
        0x03,
        0x04,
        0x05,
        0x06,
        0x07,
        0x08,
        0x09,
        0x0A,
        0x0B,
        0x0C,
        0x0D,
        0x0E,
        0x152,
        0x147,
        0x149,
        0x145,
        0x135,
        0x37,
        0x4A,
        0x0F,
        0x10,
        0x11,
        0x12,
        0x13,
        0x14,
        0x15,
        0x16,
        0x17,
        0x18,
        0x19,
        0x1A,
        0x1B,
        0x2B,
        0x153,
        0x14F,
        0x151,
        0x47,
        0x48,
        0x49,
        0x4E,
        0x3A,
        0x1E,
        0x1F,
        0x20,
        0x21,
        0x22,
        0x23,
        0x24,
        0x25,
        0x26,
        0x27,
        0x28,
        0x1C,
        0x4B,
        0x4C,
        0x4D,
        0x2A,
        0x2C,
        0x2D,
        0x2E,
        0x2F,
        0x30,
        0x31,
        0x32,
        0x33,
        0x34,
        0x35,
        0x36,
        0x148,
        0x4F,
        0x50,
        0x51,
        0x11C,
        0x1D,
        0x15B,
        0x38,
        0x39,
        0x138,
        0x15C,
        0x15D,
        0x11D,
        0x14B,
        0x150,
        0x14D,
        0x52,
        0x53,
    };

    
    string findKey(int key) {
        string r = null;
        for (int i = 0; i < keyboardNums.Length; i++) {
            if (keyboardNums[i] == key) {
                r = keyboardWords[i];
            }
        }
        print(key + " pretvorjen v " + r);
        return r;
    }
    
    void sortArray() {
        for (int i = 0; i < keyboardNums.Length - 1; i++) {
            if (keyboardNums[i + 1] < keyboardNums[i]) {
                int temp = keyboardNums[i + 1];
                keyboardNums[i + 1] = keyboardNums[i];
                keyboardNums[i] = temp;
                string tmp = keyboardWords[i + 1];
                keyboardWords[i + 1] = keyboardWords[i];
                keyboardWords[i] = tmp;
            }
        }
    }

    int red, blue, green;

	int[] mavricaR = {100,100,100,50,0,0,0,0,0,50,100,100};
	int[] mavricaG = {0,50,100,100,100,100,100,50,0,0,0,0};
	int[] mavricaB = {0,0,0,0,0,50,100,100,100,100,100,0,50};

	int stopnjaTezavnosti;
	int stIzgub;
	int score;
	int scorePlus;
    int zeResenih;
    string trenutnoIskanaTipka;

    int[] zaporedje;
    bool isEnabled = true;
    System.Random random = new System.Random();

    // CAS
    float timestamp;
    float tempCas;
    double timer = 5;

    void Start () {
        sortArray();
        LogitechGSDK.LogiLedInit();
		red = 0;
		blue = 0;
		green = 0;
		LogitechGSDK.LogiLedSetLighting(red,blue,green);

		stopnjaTezavnosti = 5;
		stIzgub = 0;
		score = 0;
		scorePlus = 1;
		zaporedje = new int[12];

		for (int i = 0; i < stopnjaTezavnosti; i++) {
			int barva = random.Next(0, 11);
			red = mavricaR [i];
			green = mavricaG [i];
			blue = mavricaB [i];

			int nasTipka = random.Next(0, 0x53);
			zaporedje [i] = nasTipka;
			LogitechGSDK.LogiLedSetLightingForKeyWithScanCode(nasTipka, red, green, blue); 

            // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
			for (int j = 0; j < 25000000; j++) {
				barva = random.Next(0, 11);
			}

			LogitechGSDK.LogiLedSetLighting(0,0,0);

            
        }
        // ZAPOREDJA JE KONEC; UPORABNIK ZACNE PONAVLJATI
        zeResenih = 0;
        // preberi pritisnjeno tipko
        trenutnoIskanaTipka = findKey(zaporedje[zeResenih]);
        print("trenutno iskana: " + trenutnoIskanaTipka);
    }

    // Update is called once per frame
    void Update() {

        string pritisnjeno = Input.inputString;
        print("pritisnjen gumb: " + pritisnjeno);

        // je bila pritisnjena prava tipka?
        if (pritisnjeno.Equals(trenutnoIskanaTipka))
        {
            print("pravi gumb!" + pritisnjeno);
            LogitechGSDK.LogiLedSetLighting(30, 30, 50);

            // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
            for (int j = 0; j < 10000000; j++)
            {
                int barva = random.Next(0, 11);
            }

            LogitechGSDK.LogiLedSetLighting(0, 0, 0);

            zeResenih++;
            if (zeResenih == stopnjaTezavnosti)
            {

                LogitechGSDK.LogiLedSetLighting(0, 100, 0);

                // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
                for (int j = 0; j < 30000000; j++)
                {
                    int barva = random.Next(0, 11);
                }

                LogitechGSDK.LogiLedSetLighting(0, 0, 0);

                LogitechGSDK.LogiLedShutdown();
                isEnabled = false;
            }
            else
            {
                trenutnoIskanaTipka = findKey(zaporedje[zeResenih]);

                
            }

        // nic ni bilo pritisnjeno
        } else if (pritisnjeno.Equals("")) {
            
        // napacna tipka
        } else
        {
            print("Napacna tipka!" + pritisnjeno);
            YouLost();
            
        }
        if (!isEnabled) return;

    }

    void YouLost() {
        print("you lčoszt!");
        //LogitechGSDK.LogiLedFlashLighting(60, 20, 0, 1000, 1000);
        LogitechGSDK.LogiLedSetLighting(60, 20, 0);

        // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
        for (int j = 0; j < 10000000; j++)
        {
            int barva = random.Next(0, 11);
        }

        LogitechGSDK.LogiLedSetLighting(0, 0, 0);

        stIzgub++;
        print(stIzgub);
        if (stIzgub > 3) {
            LogitechGSDK.LogiLedSetLighting(100, 0, 0);

            // ZAMENJAJ S TIMERJEM!! - cakanje koliko casa je tipka prizgana, preden se ugasne
            for (int j = 0; j < 10000000; j++)
            {
                int barva = random.Next(0, 11);
            }

            LogitechGSDK.LogiLedSetLighting(0, 0, 0);
            LogitechGSDK.LogiLedShutdown();
            isEnabled = false;
            //Application.Quit();
        }
        
    }
}

/*
TO DO:
o - izpisi mavrico
o - shranjuj zaporedje
o - preveri ce igralec pritiska prave tipke
*/

