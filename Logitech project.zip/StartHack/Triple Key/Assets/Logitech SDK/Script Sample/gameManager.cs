﻿using UnityEngine;
using System.Collections;

public class gameManager : MonoBehaviour { 

    public static gameManager gm;
    public GameObject mainCanvas;
    public GameObject instructions1, instructions2, instructions3;
    public GameObject game1, game2, game3;

    System.Random random = new System.Random();

    // Use this for initialization
    void Start () {

        /*mainCanvas = gameObject.GetComponent<GameObject>();
        instructions1 = gameObject.GetComponent<GameObject>();
        instructions2 = gameObject.GetComponent<GameObject>();
        instructions3 = gameObject.GetComponent<GameObject>();*/

        //game1 = gameObject.GetComponent<GameObject>();
        //game2 = gameObject.GetComponent<GameObject>();
        //game3 = gameObject.GetComponent<GameObject>();

        for (int i = 0; i < 3; i++)
        {
            int igra = random.Next(0, 2);
            //int stopnjaIgre = random.Next()
            if (igra == 0)
            {
                game1.SetActive(true);
                //instructions1.SetActive(true);
                //instructions2.SetActive(false);
                //instructions3.SetActive(false);
                game2.SetActive(false);
                game3.SetActive(false);
            }
            else if (igra == 1)
            {
                game1.SetActive(false);
                //instructions1.SetActive(false);
                //instructions2.SetActive(true);
                //instructions3.SetActive(false);
                game2.SetActive(true);
                game3.SetActive(false);
            }
            else
            {
                game1.SetActive(false);
                game2.SetActive(false);
                game3.SetActive(true);
                //instructions1.SetActive(false);
                //instructions2.SetActive(false);
                //instructions3.SetActive(true);
            }
        }
        Application.Quit();           
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
